---

# File
file: third-page
permalink: resource/myFile3
aliases:
  - file3
  - fileA3
lang: en
sitemap: 
hidden: 

# Layout
layout: 
template: 
classes: 

# Content
title: My post 3
title-before: 
title-after: 
subtitle: Subtitle 3
description: My post desc 3
excerpt: 
custom-excerpt: 
featured-image: 
caption: 
teaser-image: 
featured-logo: 
link: 
intro: This is life.
embed: embed 3
table-of-contents: some content 3
outro: it's over.

# Meta
featured: 
priority: 2
status: pubilshed
date: 2024-07-17
last-modified-at: 
author: 
author-profile: 
show-page-title: 
show-date: 
show-footer-date: 
show-pagination: 
show-taxonomy: 
comments: 
read-time: 
related: 
share: 
allow-recursion: 

# Navigation
navigation: 
breadcrumbs: 
resource: 
actions-label: 

# Header

# Sidebar
toc: 
toc-sticky: 
toc-label: 
toc-icon: 
post-aside: 
sidebar:


# Additional content
gallery: 
feature-row: 
feature-row2: 
feature-row3: 
title-display: 
categories:
  - business
tags:

info1:

info2:


---


{% capture include_markdown %}
{% include_relative {{ page.content_folder | default: site.content_folder }}/{{ page.file }}.md %}
{% endcapture %}
{{ include_markdown | markdownify }}

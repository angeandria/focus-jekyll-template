---
id: third-page
content_file: "[[_content/third-page.md]]"
permalink: /resource/myFile3
aliases: 
  - file3
  - fileA3  
categories:
  - business
tags:
  - 
info-1: 
  -   
info-2: 
  - 
---


{% capture include_markdown %}
{% include_relative _content/third-page.md %}
{% endcapture %}
{{ include_markdown | markdownify }}